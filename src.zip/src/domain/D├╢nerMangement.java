package domain;

public class DönerMangement {

}
