package domain;

public class Dönermann {

}
