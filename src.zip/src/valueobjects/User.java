package valueobjects;

public class User {

	private String name;
	private String number;
	private String email;
	private String password;
	
	public User(String name, String number, String email, String password) {
		this.name = name;
		this.number = number;
		this.email = email;
		this.password = password;
	};
	
	
}
