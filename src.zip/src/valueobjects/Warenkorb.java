package valueobjects;

public class Warenkorb {
	
}
